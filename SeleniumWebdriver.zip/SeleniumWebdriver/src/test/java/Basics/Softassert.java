
package Basics;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Softassert {

   @Test
    public void testSoftAssert() {
        SoftAssert softAssert = new SoftAssert();

        System.out.println("Step 1");
        softAssert.assertEquals("Hello", "Hi"); // Fails but continues
        System.out.println("Step 2");
        softAssert.assertTrue(false); // Fails but continues
        softAssert.assertAll();
        softAssert.assertAll();

}
}

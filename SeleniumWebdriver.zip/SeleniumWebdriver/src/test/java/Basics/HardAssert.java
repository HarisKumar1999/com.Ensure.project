package Basics;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HardAssert {

@Test
    public void testHardAssert() {
        System.out.println("Step 1");
        Assert.assertEquals("Hello", "Hi"); // Fails here
        System.out.println("Step 2"); // Will NOT execute
    }
}



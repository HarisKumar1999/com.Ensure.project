package Basics;

public class ImageScale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package Basics;


	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Set;

	public class Paytm {
	    public static void main(String[] args) throws InterruptedException {
	        // Set ChromeDriver path
	       // System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");

	        WebDriver driver = new ChromeDriver();
	        driver.manage().window().maximize();

	        // 1. Launch Paytm
	        driver.get("https://paytm.com/");
	        Thread.sleep(3000);
	        
	        // 2. Move to  on Ticket Booking
	        Actions action = new Actions(driver);
	       WebElement element = driver.findElement(By.xpath("//*[text()='Ticket Booking']"));
	       action.moveToElement(element).perform();
	        Thread.sleep(2000);


	        // 2. Click on Ticket Booking
	        driver.findElement(By.xpath("//*[text()='Bus Tickets']")).click();
	        Thread.sleep(2000);

	        String parentwindow = driver.getWindowHandle();
	        Set<String> allwindow = driver.getWindowHandles();
	        for(String window : allwindow) {
	        	if(!window.equals(parentwindow)) {
	        		driver.switchTo().window(window);   
	        		break;
	        		}
	        }
	        
	        WebDriverWait wait  = new WebDriverWait(driver, Duration.ofSeconds(5));
	        WebElement src = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dwebSourceInput")));
	        // 4. Enter From and To locations
	      // WebElement src= driver.findElement(By.id("dwebSourceInput"));
	        src.sendKeys("New Delhi (Delhi)");
	        src.click();
	        
	        Thread.sleep(1000);
	        WebElement src1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dwebDestinationInput")));
	        src1.sendKeys("Jaipur");
	       // driver.findElement(By.id("dwebDestinationInput")).sendKeys("Hyderabad");
	       // Thread.sleep(1000);
	       // driver.findElement(By.id("ac")).click();
	        // Select date (optional)
	       
	       // driver.findElement(By.xpath("//div[@class='_3i2Wp']//span[text()='25']")).click(); // Example date
	       // Thread.sleep(1000);

	        // 5. Click Search
	        driver.findElement(By.xpath("//*[text()='Search Buses']")).click();
	        Thread.sleep(5000);

	        // 6. Store list of 10 buses with price
	        List<WebElement> busNames = driver.findElements(By.xpath("//div[@class='_2fX6l']")); // Bus name locator
	        List<WebElement> busPrices = driver.findElements(By.xpath("//div[@class='_2MkSl']")); // Price locator

	        System.out.println("Top 10 Buses and Prices:");
	        for (int i = 0; i < 10 && i < busNames.size(); i++) {
	            String name = busNames.get(i).getText();
	            String price = busPrices.get(i).getText();
	            System.out.println((i + 1) + ". " + name + " - " + price);
	        }

	        driver.quit();
	    }
	}


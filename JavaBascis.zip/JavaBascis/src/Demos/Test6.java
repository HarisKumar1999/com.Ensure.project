package Demos;

public class Test6 {

	public static void main(String[] args) {

try {
	int result=10/0;	
	 System.exit(0);
	}
catch(Exception e) {
	System.out.println(e.getMessage());
	System.out.println(e);
	 
 }
finally {
	System.out.println("Test always");
}

	}

}

package Demos;

public class InterchangeWords {

	public static void main(String[] args) {
		//int [] a= {20,788,45,24,7,89,90,567};
		//System.out.println(a[1]);
		String input ="Harish Kumar";
		String [] words = input.split(" ");
		System.out.println(words[1]+ " "+ words[0]);
	}

}

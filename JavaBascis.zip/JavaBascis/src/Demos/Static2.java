package Demos;

public class Static2 {
	static String name="Harish";
	static int rollno=1234;
	
	public static void testing() {
		System.out.println(name);
		System.out.println(rollno);
	}
	
	public static void main(String[] args) {
		testing();
	}
	
	
	
	
	
	
	
}

	


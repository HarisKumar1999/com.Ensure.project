package Demos;

public class swapping {

	public static void main(String[] args) {
		/*int a=10,b=20,temp;
		temp=a;
		a=b;
		b=temp;
		System.out.println("After swap a :" + a+ ",b :"+b);*/
		
		
		 // a=a+b+c;
		   // b=a-(b+c);
		   // c=a-(b+c);
		    //a=a-(b+c);
		int a=10,b=20;
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After swap a is :"+ a + ", b is: "+b);
		
	}

}

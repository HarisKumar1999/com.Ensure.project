package Demos;

public class MixedString {

	public static void main(String[] args) {
		int Lettercount=0;
		int digitcount=0;
		int specialcount=0;
		String input = "Automa3436@$%gt45";
		for(int i=0;i<input.length();i++) {
			char ch =input.charAt(i);
			if(Character.isLetter(ch)) {
				Lettercount++;
			}
			else if(Character.isDigit(ch)) {
				digitcount++;
			}
			else {
				specialcount++;
			}
		}
		
		System.out.println("Letter :"+Lettercount);
		System.out.println(digitcount);
		System.out.println(specialcount);
	}

}

package Demos;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyChar {

	public static void main(String[] args) {
		String input = "Helloworld";

		 // Create a LinkedHashMap to store character frequencies
		        // LinkedHashMap maintains the order in which characters are inserte

		Map<Character,Integer> freqmap = new LinkedHashMap<>(); 
		
		for(int i=0;i<input.length();i++) {  //  // Loop through each character in the input string
			char ch = input.charAt(i);   // Get the character at index i
			if(freqmap.containsKey(ch)) {  //  // Check if the character is already in the map
				freqmap.put(ch, freqmap.get(ch)+1); // // If yes, increment its count by 
			}else {   
				freqmap.put(ch,1);   // If not, add it to the map with a count of 1
				
			}
		}
			
		 // Loop through the map entries to print each character and its frequenc
			for(Map.Entry<Character, Integer> entry : freqmap.entrySet()) {
				   // Print the frequency followed by the character (e.g., 2h)
			System.out.println(entry.getValue()+ " : " +entry.getKey());
				
			}
			
		}

	}


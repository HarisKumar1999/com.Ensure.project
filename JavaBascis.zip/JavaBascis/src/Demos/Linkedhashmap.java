package Demos;

import java.util.LinkedHashMap;

public class Linkedhashmap {

	public static void main(String[] args) {
		LinkedHashMap<String ,Integer> lmap = new LinkedHashMap<>();
		lmap.put("Harish", 1);
		lmap.put("Kumar", 2);
		lmap.put("gowd", 3);
		//System.out.println(lmap.keySet());
		System.out.println(lmap.containsKey(2));

	}

}

package Demos;

import java.util.Arrays;

public class SortArray {

	public static void main(String[] args) {
		int [] arr = {1,9,4,7,2,6};
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		

	}

}

package Demos;

public class WordsinDoubleQuotes {
	public static void main(String[] args) {
		String input = "Selenium Java Automation";
		String [] word = input.split(" ");
		//System.out.println(word[2]+ " "+word[1]+ " "+word[0]);
		System.out.println("\""+word[2]+"\""+","+"\""+word[1]+"\""+","+"\""+word[0]+"\"");
		
	}
}

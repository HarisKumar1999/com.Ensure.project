package Demos;

public class Array_Largest_Number {

	public static void main(String[] args) {
	int value [] = {3,5,13,22,33,41,65,24,63,9,44};
	int largest=Integer.MIN_VALUE;
	int Secondlargest=Integer.MIN_VALUE;
	for(int num  : value) {
		if(num > largest) {
			Secondlargest = largest;
			largest = num;
		}
		else if(num > Secondlargest &&  num!=largest) {
			Secondlargest = num;
		}
		
	}
	System.out.println("Largest number is :" +largest);
	System.out.println("Secondlargest number is :" +Secondlargest);
	}

}

package Demos;

public class NonStatic {
	int elementId=100;
		
	
	public void testing() {
		System.out.println(elementId);
	}
	
	public static void main(String[] args) {
		NonStatic obj = new NonStatic();
		obj.testing();
	}
}

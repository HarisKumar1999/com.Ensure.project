package Demos;

import java.util.HashMap;

public class Hashmap {

	public static void main(String[] args) {
		HashMap<String,Integer> map = new HashMap<>();
		map.put("Harish",1);
		map.put( "Kumar",2);
		map.put("Gowd",3);
		System.out.println(map.keySet());

	}

}

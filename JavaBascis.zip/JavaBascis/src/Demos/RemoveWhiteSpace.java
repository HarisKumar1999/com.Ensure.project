package Demos;

public class RemoveWhiteSpace {

	public static void main(String[] args) {
		String input = "Harish Kumar Gowd";
		System.out.println(input.replaceAll("\\s+",""));

	}

}

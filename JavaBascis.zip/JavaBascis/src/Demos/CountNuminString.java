package Demos;

public class CountNuminString {

	public static void main(String[] args) {
		//String input ="abc 12 def 45 67 ghi";
		String input = "4fdgd6dgd6";
		String [] words = input.split("\\D+");
		int sum=0;
		for(String word : words) {
			if(!word.isEmpty()) {
				sum+=Integer.parseInt(word);
			}
			
		}
		 
		System.out.println(sum);

	}

}

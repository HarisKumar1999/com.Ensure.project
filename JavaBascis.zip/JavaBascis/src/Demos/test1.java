package Demos;

import java.util.LinkedHashMap;
import java.util.Map;

public class test1 {
public static void main(String[]args) {
	String input="aabbb";
	Map<Character,Integer> freqmap = new LinkedHashMap<>();
	for(int i=0;i<input.length();i++) {
		char ch = input.charAt(i);
		if(freqmap.containsKey(ch)) {
			freqmap.put(ch, freqmap.get(ch)+1);
		}else {
			freqmap.put(ch, 1);
			
		}
	}
	for(Map.Entry<Character,Integer> entry : freqmap.entrySet()){
		System.out.print(entry.getValue()+ ""+entry.getKey());
	}
	
	
	
}

}

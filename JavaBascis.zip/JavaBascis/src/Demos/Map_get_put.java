package Demos;

import java.util.HashMap;
import java.util.Map;

public class Map_get_put {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map <String ,Integer> map = new HashMap<>();
		map.put("apple", 1);  //Insert key and value pairs
		map.put("Banana", 2);
		map.put("lemon", 3);
		
		map.put("apple", 10);  //update value from 1 to 10
		
		System.out.println(map.get("apple"));
		System.out.println(map.get("Banana"));
		System.out.println(map.get("lemon"));

	}

}

package Demos;

public class Reversewords {

	public static void main(String[] args) {
		String input = "Java is Fun";
		String [] words = input.split(" ");
		StringBuilder result = new StringBuilder();
		for (String word : words) {
			result.append(new StringBuilder(word).reverse()).append(" ");
		}
		System.out.println(result.toString().trim());

	}

}

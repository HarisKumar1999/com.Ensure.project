package Demos;

public class StringWordReverse {

	public static void main(String[] args) {
		String input = "Java is Fun";
		String result = " ";
		String [] words = input.split(" ");
		for(String word : words) {
			String rev= " ";
			for(int i=word.length()-1;i>=0;i--) {
				rev+=word.charAt(i);
			}
			result+=rev+"";
		}
		System.out.println(result.trim());

	}

}

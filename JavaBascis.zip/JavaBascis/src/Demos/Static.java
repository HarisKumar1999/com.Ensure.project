package Demos;

public class Static {
	 static String compname="Capgemini";         //String variable
	 
	 static  void Showcompname() {         //Static method
		System.out.println("Company name:"+compname);
		
	}
	
	public static void main (String[] args) {   // Main method
		Showcompname();                         //Accessing static method and variable directly
	}
	}

//


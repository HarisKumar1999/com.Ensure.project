package Demos;

public class BreakandContinue {

	public static void main(String[] args) {
		// Break - terminate the loop completely
	/*	for(int i=1;i<=5;i++) {
			if(i==3) {
				break;
			}
			
			System.out.println(i);
		}*/
		
		//Continue - Skip the current iteration and move to next iteration
		for(int i=1;i<=5;i++) {
			if(i==3) {
				continue;
			}
			System.out.println(i);
		}
	}

}

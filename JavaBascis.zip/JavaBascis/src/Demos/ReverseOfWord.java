package Demos;

public class ReverseOfWord {

	public static void main(String[] args) {
		String input ="Java is Fun";   //input of String
		char [] chars =input.toCharArray();  //converts String into character
		String result =" ";   //Final output string
		String word ="";      //Temporary string to hold each word
	
		for(int i=0;i<chars.length;i++) {    //  // Loop through each character in the array
			if(chars[i]!=' ') {         //logical NOT operator.
				word+=chars[i];     // Build the word character by character
			}
			else {
				for(int j=word.length()-1;j>=0;j--) {   // Reverse the word manually
					result+=word.charAt(j);   //Append characters in reverse order
				}
				result+= " ";  //Add space after reversed word
				word = "";   //Reset word for next one
			}
		}
		for(int j=word.length()-1;j>=0;j--) {   // Reverse and add the last word (after the loop ends
			result+=word.charAt(j);   // Reverse and add the last word (after the loop ends
		}
		System.out.println(result);
	}

}
package Demos;

import java.util.Arrays;
import java.util.List;

public class AsList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*List<String> input = Arrays.asList("Java","Selenium","Automation");
		//input.add("Test");
		input.set(1, "quality");
		input.reversed();
		System.out.println(input);
	}

}*/
		
		//List<String> input = Arrays.asList("Java","Selenium",)
		
	}
}

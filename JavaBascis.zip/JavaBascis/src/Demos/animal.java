package Demos;

public class animal {
	void sound() {
		System.out.println("Animal makes a sound");
	}

	class Dog extends animal{
		//void sound() {
		//System.out.println("Dog barks a sound")
		}
	}


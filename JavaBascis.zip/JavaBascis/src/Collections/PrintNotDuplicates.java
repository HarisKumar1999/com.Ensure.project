package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PrintNotDuplicates {

	public static void main(String[] args) {
		 String input = "BIG BANG BIG BANG BACK SIT";
	        String [] parts = input.split("\\s+");
	        Set<String>set = new HashSet<>();
	        List<String> list = new ArrayList<>();
	        
	        for(String i : parts){
	           if(!set.add(i)){
	           list.add(i);
	        }
	        }
	        
	        
	List<String> nonRepeating = new ArrayList<>();
	        for (String i : parts) {
	            if (!list.contains(i)) {
	                nonRepeating.add(i);
	}
	}
	//System.out.println(String.join(" ", nonRepeating));
	System.out.println("Print Not Duplicate:"+nonRepeating);
	        System.out.println("Remove Duplicates :"+set);
	         System.out.println("Print only duplicates:"+list);
	         System.out.println(String.join(" ", set))	;
	         
	         }
	}

	

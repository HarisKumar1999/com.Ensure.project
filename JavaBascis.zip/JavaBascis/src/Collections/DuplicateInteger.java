package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.*;

public class DuplicateInteger {

	public static void main(String[] args) {
	List<Integer> list = new ArrayList<>(Arrays.asList(1,3,4,1,6,7,3,4,9));
	Set<Integer> set = new LinkedHashSet<>(list);
	System.out.println(set);
	List<Integer> alist=new LinkedList<>(set);
	System.out.println(alist);
	System.out.println(alist.addAll(alist));

	}

}

package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class FindDuplicateString {

	public static void main(String[] args) {
		String [] input = {"Harish","Kumar","Test","Harish"};
		Set<String> set = new LinkedHashSet<>();
		List<String>duplicate = new ArrayList<>();
		for(String i:input) {
			if(!set.add(i)) {
			duplicate.add(i);
		}
		}
			System.out.println(duplicate);
		}

}


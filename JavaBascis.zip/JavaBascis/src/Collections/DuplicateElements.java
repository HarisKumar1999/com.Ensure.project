package Collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class DuplicateElements {

	public static void main(String[] args) {
	List<String> list = new ArrayList<>(Arrays.asList("Harish","Tester","Harish","Gaming","playing","Tester"));
	Set<String> set = new LinkedHashSet<>(list);
	System.out.println(set);
	//List<String>alist = new ArrayList<>(set);
	//System.out.println(alist);
	
	

	}

}

package Collections;

public class Array {

	public static void main(String[] args) {
		//int  [] a = {1,2,3,4};
	      // System.out.println(a.length-1);
		
		int [] [] arr = new int [3][3];
		for(int i=0;i<arr.length;i++) {
			for(int j=0;j<arr[i].length;j++) {
				arr[i][j] = i + j;
			
		}
		

	}

		 
		       


		        // 3) Print the matrix
		        System.out.println("Matrix (3x3):");
		        printMatrix(arr);
		        }
}

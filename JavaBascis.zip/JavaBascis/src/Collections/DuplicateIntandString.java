package Collections;

import java.util.Arrays;
import java.util.*;
public class DuplicateIntandString {

	public static void main(String[] args) {
		List<Object> obj = new ArrayList<>(Arrays.asList("Harish",1,"Team",4,1,"Harish",4));
		Set<Object> set = new LinkedHashSet<>(obj);
		System.out.println(set);
		set.add("quality");
		System.out.println(set);

	}

}

package Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindDuplicatesinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = {1,2,3,4,1,2,3};
		Set<Integer> set = new HashSet<>();
		List<Integer> dupliacte = new ArrayList<>();
		for(int i:arr)
			if(!set.add(i)){
			dupliacte.add(i);
				
			}
		System.out.println(set);
		System.out.println(dupliacte);

	}

}

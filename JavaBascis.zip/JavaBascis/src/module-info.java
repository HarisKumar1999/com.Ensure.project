/**
 * 
 */
/**
 * 
 */
module JavaBascis {
}
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.response.Response;
public class GetMethod {

	//@Test(priority=1)
	void testGetMethod() {
		given()
		.header("x-api-key", "YOUR_API_KEY")
		.when()
		.get("https://reqres.in/api/users?page=2")
		.then()
		.statusLine("HTTP/1.1 200 OK")
		.body("per_page", equalTo(6))
		.body("data[0].id", equalTo(7))
		.body("data[5].email", equalTo("rachel.howell@reqres.in"))
		.cookies(null)
		.statusCode(200)
		.log().all();
		
	}

	
	//Get one cookie
	@Test(priority=1)
	void testGetMethod1() {
		 RestAssured.useRelaxedHTTPSValidation();
		Response res = given()
		//.header("x-api-key", "YOUR_API_KEY")
		.when()
		.get("https://google.com");
		//cookie
		String cookievalue = res.getCookie("AEC");
		String cookievalue1 =res.getCookie("NID");
		System.out.println(cookievalue1);
		System.out.println(cookievalue);
		Map<String, String> cook = res.getCookies();
		for(String k:cook.keySet()) {
			String test = res.getCookie(k);
			System.out.println(test);
			
	}
				
		//Header
		String head1 = res.getHeader("Content-Type");
		System.out.println(head1);
		 Headers head2 = res.getHeaders();
		 System.out.println(head2);

}
}


import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
public class SeializationandDeserial {
	
	@Test
	void Serial() throws JsonProcessingException {
		User u = new User();
		u.setName("Harish");
		u.setRollno(12345);
		ObjectMapper objmap = new ObjectMapper();
		String JSONdata = objmap.writerWithDefaultPrettyPrinter().writeValueAsString(u);
		System.out.println(JSONdata);
		ObjectMapper obj = new ObjectMapper();
		
	}
	 @Test
	void deserialization() throws JsonMappingException, JsonProcessingException{
		
	String Jsonbody = " {\r\n"
			+ "  \"rollno\" : 12345,\r\n"
			+ "  \"name\" : \"Harish\"\r\n"
			+ "}";	
	ObjectMapper objmapp = new ObjectMapper();
	User  pojobody = objmapp.readValue(Jsonbody, User.class);
	System.out.println(pojobody.getName());
	System.out.println(pojobody.getRollno());
	}
}


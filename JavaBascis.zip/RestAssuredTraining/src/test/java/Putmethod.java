import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Putmethod {
	@Test
	void putmethod() {

		 RestAssured.useRelaxedHTTPSValidation();
		        RestAssured.baseURI = "https://restful-booker.herokuapp.com";

		        // 1) Create a booking to get a fresh bookingId
		        String createBody = "{\n" +
		                "  \"firstname\": \"Jim\",\n" +
		                "  \"lastname\": \"Brown\",\n" +
		                "  \"totalprice\": 111,\n" +
		                "  \"depositpaid\": true,\n" +
		                "  \"bookingdates\": {\n" +
		                "    \"checkin\": \"2018-01-01\",\n" +
		                "    \"checkout\": \"2019-01-01\"\n" +
		                "  },\n" +
		                "  \"additionalneeds\": \"Breakfast\"\n" +
		                "}";

		        Response createRes = given()
		                .contentType(ContentType.JSON)
		               .body(createBody)
		            .when()
		                .put("/booking");

		        createRes.then()
		                .log().all()
		                .statusCode(anyOf(is(200), is(201)))
		                .body("bookingid", notNullValue());

		      int bookingId = createRes.jsonPath().getInt("bookingid");
		        System.out.println("Created bookingId: " + bookingId);

		        // 2) Get auth token
		        String authBody = "{ \"username\": \"admin\", \"password\": \"password123\" }";

		        String token = given()
		               .log().all()
		                .contentType(ContentType.JSON)
		                .body(authBody)
		            .when()
		                .post("/auth")
		            .then()
		                .log().all()
		                .statusCode(200)
		                .extract()
		                .path("token");

		        System.out.println("Token: " + token);

		        // 3) Prepare your PUT payload
		        String putBody = "{\n" +
		                "  \"firstname\": \"James\",\n" +
		                "  \"lastname\": \"Brown\",\n" +
		                "  \"totalprice\": 111,\n" +
		                "  \"depositpaid\": true,\n" +
		                "  \"bookingdates\": {\n" +
		                "    \"checkin\": \"2018-01-01\",\n" +
		                "    \"checkout\": \"2019-01-01\"\n" +
		                "  },\n" +
		                "  \"additionalneeds\": \"Afternoon\"\n" +
		                "}";

		        // 4) PUT update using Cookie token
		        Response putRes = given()
		                .log().all()
		                .contentType(ContentType.JSON)
		                .accept(ContentType.JSON)
		                .cookie("token", token)           // <- required for PUT/PATCH/DELETE
		                .header("Cookie", "token=" + token)    
		                .body(putBody)
		            .when()
		                .put("/booking/" + bookingId);

		        // 5) Verify response body + headers
		        putRes.then()
		                .log().all()
		                .statusCode(anyOf(is(200), is(201)))
		                .header("Content-Type", containsString("application/json"))
		                .body("firstname", equalTo("James"))
		                .body("lastname", equalTo("Brown"))
		                .body("bookingdates.checkn", equalTo("2018-01-01"));
		         
		        // Optional: GET to confirm persisted change

		        given()
		               .log().all()
		               .accept(ContentType.JSON)
		           .when()
		               .get("/booking/" + bookingId)
		           .then()
		               .log().all()
		               .statusCode(anyOf(is(200), is(201)))
		               .body("firstname", equalTo("James"))
		               .body("additionalneeds", equalTo("Afternoon"));

	}
	

}

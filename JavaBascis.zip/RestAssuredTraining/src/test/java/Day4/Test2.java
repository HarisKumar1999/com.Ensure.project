package Day4;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class Test2 {
	@Test
	
	void testing() {
		given()
		.queryParam("id", 1)
		.pathParam("id", 1)
		.when()
		.get("https://jsonplaceholder.typicode.com/posts/1")
		.then()
		
		.log().all();
	}
	

}

package Day4;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class Test1 {
	@Test
    public void testing() {
       // Response response = RestAssured.get("https://jsonplaceholder.typicode.com/posts/1");
		Response response = given()
		.when()
		.get("https://jsonplaceholder.typicode.com/posts/1");
        System.out.println("Status Code: " + response.getStatusCode());
        System.out.println("Response Body: " + response.getBody().asString());
        System.out.println("Response Body: " + response.getHeaders());
        System.out.println("Response Body: " + response.getHeader("Content-Type"));
      System.out.println(  "JSONPATH: " +response.jsonPath().toString());
  
    }
}




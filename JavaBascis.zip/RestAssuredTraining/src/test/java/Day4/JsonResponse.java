package Day4;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class JsonResponse {
	@Test(priority=1)
	 void testJSONResponse() {   // 1 approach
		/*given()
		 .accept("ContentType.JSON")
		.contentType("ContentType.JSON")
		.when()
		.get("https://jsonpathfinder.com/")
		.then()
		.statusCode(200)
		.header("referrer-policy", "strict-origin-when-cross-origin")
		.body("[1].personal.favorite_color",equalTo("Maroon"))
		.log().all();*/
		
		//2 Approach
		Response res  = given()
		.contentType(ContentType.JSON)
		.when()
		.get("https://jsonpathfinder.com/");
		Assert.assertEquals(res.getStatusCode(), 200);
		Assert.assertEquals(res.getHeader("Content-Type"), "text/html; charset=utf-8");
		String bookname = res.jsonPath().get("x[4].last_name").toString();
		Assert.assertEquals(bookname, "Mawhinney");
	}

}

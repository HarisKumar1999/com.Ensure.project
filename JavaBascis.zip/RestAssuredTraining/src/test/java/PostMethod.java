import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
public class PostMethod {
	
	
	//@Test(priority=1)
	void testpost() {
		RestAssured.useRelaxedHTTPSValidation();
	String Jsonbody = "{ \"username\": \"admin\", \"password\": \"password123\" }";
	Response res = given()
			.contentType(ContentType.JSON)
			.body(Jsonbody)
			.when()
			.post("https://restful-booker.herokuapp.com/auth");
	System.out.println("Status code :"+res.getStatusCode());
	System.out.println("Response Body :"+res.getBody().asString());
	
	}
	//Response id;
	
//	@Test(priority=2)
	void testPost2method() {
		RestAssured.useRelaxedHTTPSValidation();
	
		HashMap<String,String> data = new HashMap<>();
		data.put("username", "admin");
		data.put("password", "password123");
	Response res = 	 given()
		.contentType(ContentType.JSON)
		.body(data)
		.when()
		.post("https://restful-booker.herokuapp.com/auth");
	res.then()
	.statusCode(200);

		System.out.println("Status: " + res.statusLine());
        System.out.println("Token: " + res.jsonPath().getString("token"));
        System.out.println("Status: " + res.body());
        System.out.println("Response Body :"+res.getBody().asString());


		// .then()
		// .statusCode(200);
		// .body("token", notNullValue());  
		// System.out.println(id);
	}
	@Test
	void testpost2() {
		RestAssured.useRelaxedHTTPSValidation();   // 1) Ignore SSL certificate issues (handy for test envs)
	String Jsonbody = "{ \"username\": \"admin\", \"password\": \"password123\" }"; //2) The JSON payload that /auth expects
	RequestSpecification res = RestAssured.given();  //) Start building the request specification
	res.contentType(ContentType.JSON); //) Set Content-Type header to application/json
	res.body(Jsonbody);  //	5) Attach the JSON body to the request

	res.baseUri("https://restful-booker.herokuapp.com/auth");   // 6) Set the base URI. (Here you put the full endpoint including path)
	Response req = res.post();  // 7) Execute POST to the baseUri (since no path is given)

	System.out.println(req.asPrettyString());  // 8) Print the response body nicely formatted
	}

	

	
}


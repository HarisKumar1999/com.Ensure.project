package Day3;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;


public class Loggingdemo {
	@Test
	void logging() {
		 RestAssured.useRelaxedHTTPSValidation();
		given()
		
		.when()
		.get("https://www.google.com")
		.then()
		//.log().all();
		//.log().body();
		//.log().cookies();	
		.log().headers();
	}

}

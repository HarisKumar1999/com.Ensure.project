package Day3;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;

import static io.restassured.RestAssured.given;
public class Timeout {



    public static void main(String[] args) {
    	RestAssured.useRelaxedHTTPSValidation();
        given()
        
        			.config(RestAssured.config()
            		.httpClient(HttpClientConfig.httpClientConfig()
                    .setParam("http.connection.timeout", 2_000) // connect timeout (ms)
                    .setParam("http.socket.timeout", 3_000)     // read timeout (ms)
            ))
            .when()
                .get("https://www.google.com")
            .then()
                .log().headers()   // log response headers
                .statusCode(200);  // optional: assert status code
    }


}

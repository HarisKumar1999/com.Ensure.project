package Day3;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;

public class Headers {
	//@Test(priority=1)
	void testHeader() {
		 RestAssured.useRelaxedHTTPSValidation();  //test the header
		given()
		.when()
		.get("https://www.google.com")
		.then()
		.header("Content-Type", "text/html; charset=ISO-8859-1")
		.header("Content-Encoding", "gzip")
		.header("Server", "gws");
		
	}
	@Test(priority=2)
	void getHeader() {
		 RestAssured.useRelaxedHTTPSValidation();    //single Header
		Response res = given()
		.when()
		.get("https://www.google.com");
		String getheader= res.getHeader("Content-Type");
		System.out.println(getheader);
	}
	
	@Test(priority=3)
	void getHeaders() {
		 RestAssured.useRelaxedHTTPSValidation();   //get the all headers
		Response res =  given()
		 .when()
		 .get("https://www.google.com");
		 io.restassured.http.Headers myheaders=res.getHeaders();
		io.restassured.http.Headers myheaders1=res.getHeaders();
		 for(Header hd : myheaders1) {
			 System.out.println(hd.getName()+" "+hd.getValue());
		 }
		 
	}

}

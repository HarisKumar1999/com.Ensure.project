package Day3;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CookieDemo {
	
	//@Test(priority=1)
	void cookietest() {
		 RestAssured.useRelaxedHTTPSValidation();
		given()
		.when()
		.get("https://www.google.com/")
		.then()
		.cookie("AEC","AaJma5tmtTy7nFJPN40-7ZCTtTggHqsKhlu2lCfCZeGTytiaeoGM0-QZNAs")
		.log().all();
		
	}
//	@Test(priority=2)
		void getcookies() {
		 RestAssured.useRelaxedHTTPSValidation();
	Response res =given()
		.when()
		.get("https://www.google.com");  //get the single cookie
			String cookie_value = res.getCookie("NID");
			String cookie_value1 = res.getCookie("AEC");
			System.out.println(cookie_value1);
			System.out.println(cookie_value);
		}
		@Test(priority=3)
		void getAllCookies() {
			RestAssured.useRelaxedHTTPSValidation();
		Response res = given()
			.when()
			.get("https://www.google.com");
			Map<String, String> cookie_values = res.getCookies();
			//System.out.print(cookie_values);
			//System.out.print(cookie_values.keySet());
			for(String k : cookie_values.keySet()) {
				String cookie_value = res.getCookie(k);
				System.out.println(k+" "+cookie_value);
			}
		}
	}


package Day3;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;
public class PathandQueryparam {
	
//https://reqres.in/api/users?page=2&id=5
	// "last_name": "Holt",
	@Test
	
	void PathandQueryparameters() {
	given()
	.header("x-api-key"," reqres-free-v1")
	.pathParam("mypath", "users")
	//.queryParam("page", 8)
	//.queryParam("id", 6)

	
	.when()    
	.get("https://reqres.in/api/{mypath}")        //No need to pass the query param because its static
	//.get("https://reqres.in/api/{mypath}")
	
	.then()
	.statusCode(200)
	.log().all();
	
	
	

}
}
package Day6;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;


import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;



public class JsonSchemaValidateTest {
	
	@Test
	void JsonSchemaValidation() {
		given()
		.when()
		.get("https://api.restful-api.dev/objects")
		.then()
		.assertThat().body(matchesJsonSchemaInClasspath("StorejsonSchema.json"));
	}

}

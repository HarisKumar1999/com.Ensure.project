package Day6;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Day2.Pojorequest;

public class SerializationAndDeserilization {
	
	//@Test(priority=1)
	void converPojo2Json() throws JsonProcessingException {            //creating Java object into JSON
		Student stupojo = new Student();
		stupojo.setName("Scott");
		stupojo.setLocation("france");
		stupojo.setPhone("123456");
		String coursesArr[] = {"c","c++"};
		stupojo.setCourses(coursesArr);
		//Convert Java object to JSOn
		ObjectMapper objmap = new ObjectMapper();
		String JSONdata = objmap.writerWithDefaultPrettyPrinter().writeValueAsString(stupojo);
		System.out.println(JSONdata);
	}
	
@Test
	void convertJson2Poj0() throws JsonMappingException, JsonProcessingException {
		String Jsondata="{\r\n"
				+ "  \"name\" : \"Scott\",\r\n"
				+ "  \"location\" : \"france\",\r\n"
				+ "  \"phone\" : \"123456\",\r\n"
				+ "  \"courses\" : [ \"c\", \"c++\" ]\r\n"
				+ "}";
		//Convert JSOn data to POJo Object
		ObjectMapper objmapp = new ObjectMapper();
	Student stupojo =objmapp.readValue(Jsondata, Student.class);
	System.out.println(stupojo.getName());
	System.out.println(stupojo.getLocation());
	System.out.println(stupojo.getPhone());
	System.out.println(stupojo.getLocation());
	}

}

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
public class Patchmethod {
		@Test
		void post2() {


RestAssured.useRelaxedHTTPSValidation();
        RestAssured.baseURI = "https://restful-booker.herokuapp.com";

        // 1) Create booking to get a valid ID
        String createBody = "{\n" +
                "  \"firstname\": \"Jim\",\n" +
                "  \"lastname\": \"Brown\",\n" +
                "  \"totalprice\": 111,\n" +
                "  \"depositpaid\": true,\n" +
                "  \"bookingdates\": {\n" +
                "    \"checkin\": \"2018-01-01\",\n" +
                "    \"checkout\": \"2019-01-01\"\n" +
                "  },\n" +
                "  \"additionalneeds\": \"Breakfast\"\n" +
                "}";

        int bookingId = given()
                .contentType(ContentType.JSON)
                .body(createBody)
            .when()
                .post("/booking")
            .then()
               
                .statusCode(anyOf(is(200), is(201)))
                .extract().path("bookingid");

        System.out.println("Created bookingId: " + bookingId);

        // 2) Get auth token
        String token = given()
                .log().all()
                .contentType(ContentType.JSON)
                .body("{\"username\":\"admin\",\"password\":\"password123\"}")
            .when()
                .post("/auth")
            .then()
                .log().all()
                .statusCode(200)
                .extract().path("token");

        if (token == null || token.isEmpty()) {
            throw new RuntimeException("Auth token is null/empty");
        }
        System.out.println("Token: " + token);

        // 3) PATCH payload (partial update)
        String patchBody = "{\n" +
                "  \"firstname\": \"James\",\n" +
                "  \"lastname\": \"Brown\"\n" +
                "}";

        // 4) PATCH with token cookie (+ explicit Cookie header for robustness)
        Response patchRes = given()
                .log().all()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .cookie("token", token)
                .header("Cookie", "token=" + token)
                .body(patchBody)
            .when()
                .patch("/booking/" + bookingId);

        // If non-2xx, print diagnostics and fail early
        if (patchRes.statusCode() != 200 && patchRes.statusCode() != 201) {
            System.out.println("PATCH failed with status: " + patchRes.statusLine());
            System.out.println("Response body:\n" + patchRes.asPrettyString());
            System.out.println("Response headers:");
            patchRes.getHeaders().forEach(h -> System.out.println(h.getName() + ": " + h.getValue()));
            throw new AssertionError("Expected 200/201 but got " + patchRes.statusCode());
        }

        // Assertions
        patchRes.then()
                .log().all()
                .header("Content-Type", containsString("application/json"))
                .body("firstname", equalTo("James"))
                .body("lastname", equalTo("Brown"));

}
	}

package Day2;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.annotations.Test;

import groovy.transform.stc.POJO;

public class DiffWaysCreatePostRequests {
	//By Using hashmap to create request body
	//@Test(priority=1)
	
	void postreqHashMap() {
		HashMap data = new HashMap();
		data.put("name", "Scott");
		data.put("location", "france");
		data.put("phone", "123456");
		String [] coursearr= {"c","c++"};
		data.put("courses", coursearr);
		
		given()
		.contentType("application/json")
		.body(data)
		.when()
		.post("https://local.com")
		.then()
		.statusCode(200)
		.body("name", equalTo("Scott"))
		.body("location", equalTo("france"))
		.body("phone", equalTo("123456"))
		.body("courses", equalTo("c"))
		.body("courses", equalTo("c++"))
		.log().all();
		
		
	}

	
	//Post request by using org.json library
	//@Test(priority=2)
	void postOrgJson() {
		JSONObject data = new JSONObject();
		data.put("name", "Scott");
		data.put("location", "france");
		data.put("phone", "123456");
		String [] coursearr= {"c","c++"};
		data.put("courses", coursearr);
		
		given()
		.contentType("application/json")
		.body(data.toString())
		.when()
		.post("https://local.com")
		.then()
		.statusCode(200)
		.body("name", equalTo("Scott"))
		.body("location", equalTo("france"))
		.body("phone", equalTo("123456"))
		.body("courses", equalTo("c"))
		.body("courses", equalTo("c++"))
		.log().all();
		
	}
	
	//Post request using POJO(Plain old Java object)
	//@Test(priority=3)
	void postPOJO() {
		Pojorequest data = new Pojorequest();
		data.setName("Scott");
		data.setLocation("france");
		data.setPhone("123456");
		String coursesArr[] = {"c","c++"};
		
		data.setCourses(coursesArr);
		
		given()
		.contentType("application/json")
		.when()
		.post("https://local.com")
		.then()
		.statusCode(200)
		.body("name", equalTo("Scott"))
		.body("location", equalTo("france"))
		.body("phone", equalTo("123456"))
		.body("courses", equalTo("c"))
		.body("courses", equalTo("c++"))
		.log().all();
	}
		//Post Using externalJson file
	@Test(priority=4)
	void externalJson() throws FileNotFoundException {
		File f = new File(".\\body.json");
		FileReader fr = new FileReader(f);
		JSONTokener jt = new JSONTokener(fr);
		JSONObject data = new JSONObject(jt);
		
		given()
		.contentType("application/json")
		.body(data.toString())
		.when()
		.post("https://local.com")
		.then()
		.statusCode(200)
		.body("name", equalTo("Scott"))
		.body("location", equalTo("france"))
		.body("phone", equalTo("123456"))
		.body("courses", equalTo("c"))
		.body("courses", equalTo("c++"))
		.log().all();
	}
	@Test(priority=2)
	void Deleteuser() {
		given()
		.when()
		.post("https://url")
		.then()
		.statusCode(200);
	}
	}


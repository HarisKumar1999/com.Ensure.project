package Day7;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

public class Fakerlibraries {
	@Test
	
	void testGenerateDummydata() {
		Faker faker = new Faker();
	String fullname = 	faker.name().fullName();
	String fname = faker.name().firstName();
	String lname = faker.name().lastName();
	String uname=	faker.name().username();
	String pass = 	faker.internet().password();
	String phone = faker.phoneNumber().cellPhone();
	String email = faker.internet().emailAddress();
	
	System.out.println(fullname);
	System.out.println(fname);
	System.out.println(lname);
	System.out.println(uname);
	System.out.println(pass);
	System.out.println(phone);
	System.out.println(email);
	}

}

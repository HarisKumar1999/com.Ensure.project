package Day7;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class Authentications {
	//@Test(priority=1)
	void testBasicAuthentication() {
		given()
		.auth().basic("postman", "password")
		.when()
		.get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true));
	}
	
	//@Test(priority=2)
	void testDigestAuthentication() {
		given()
		.auth().digest("postman", "password")
		.when()
		.get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true));
	}
	//@Test(priority=3)
	void testpreemptiveAuthentication() {
		given()
		.auth().preemptive().basic("postman", "password")
		.when()
		.get("https://postman-echo.com/basic-auth")
		.then()
		.statusCode(200)
		.body("authenticated",equalTo(true));
	}
	//@Test(priority=4)
	void testBearerAuthentication() {
		String bearertoken = "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";
		given()
		.headers("Authorization","Bearer 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")
		.when()
		.get("https://api.github.com/user/repos")
		.then()
		.statusCode(200)
		.log().all();
		
	}
	//@Test(priority=4)
	void testOauth1authntication() {
		given()
		.auth().oauth("consumerKey", "consumerSecret", "accessToken", "tokenSecrate")
		.when()
		.get("https://api.github.com/user/repos")
		.then()
		.statusCode(200)
		.log().all();
	}
	//@Test(priority=5)
	void testOAuth2Authnetication() {
		given()
		.auth().oauth2("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")
		.when()
		.get("https://api.github.com/user/repos")
		.then()
		.statusCode(200)
		.log().all();
}
	@Test(priority=5)
	void testAPIKey() {
		given()
		.queryParam("appid", "c709ac17d7ddcd3a65e8c7ebdb945043")
		.when()
		.get("https://api.openweathermap.org/data/2.5/weather?lat=44.34&lon=10.99&appid={API key}")
		.then()
		.statusCode(200)
		.log().all();
}
}
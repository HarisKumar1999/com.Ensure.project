import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.awt.Window.Type;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
public class Queryparam {
	//@Test(priority=1)
	void query() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		//.queryParam("firstname","sally")
		//.queryParam("lastname","brown")
		.queryParam("page", 2)
		.when()
		.get("https://reqres.in/api")
		//.get("https://restful-booker.herokuapp.com/booking")
		.then()
		.log().all()
		.statusCode(200);
	}

	
	//@Test(priority=2)
	void path() {
		given()
		.header("x-api-key"," reqres-free-v1")
		//.pathParam("mypath", "users")
		.pathParam("test", "users")
		.when()
		.get("https://reqres.in/api/{test}")
		.then()
		.log().all()
		.statusCode(200);
			
	}
	@Test(priority=3)
	void path3() {
		given()
		.header("x-api-key"," reqres-free-v1")
		//.pathParam("mypath", "users")
		.pathParam("id", 2)
		.when()
		.get("https://reqres.in/api/users/{id}")
		.then()
		.log().all()
		.statusCode(200)
		.body("data.id", equalTo(2))
		 .body("data.first_name", equalTo("Janet"));
		//.extract().jsonPath().getString("data.first_name");
		
}
}

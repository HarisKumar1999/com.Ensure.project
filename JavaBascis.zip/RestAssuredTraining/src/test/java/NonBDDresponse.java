import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class NonBDDresponse {
	@Test
	void GetSingleUser() {
		RequestSpecification req = RestAssured.given();
		req.baseUri("https://reqres.in/api/users/2");
		Response res = req.get();
		String resString = res.asPrettyString();
		System.out.println(resString);
		//Time to Validate the data
		ValidatableResponse response = res.then();
		response.statusCode(200);
		response.body("data.email", Matchers.containsString("janet.weaver@reqres.in"));
	}

}

package Day5;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
public class ParseXMLResponse {
	//@Test(priority=1)
	void testXMLresponse(){  //Approach 1
		
		given()
		.when()
		.get("https://restapi.adeuuateshop.com/api/Traveler?page=1")
		.then()
		.statusCode(200)
		.header("Content-Type","application/xml; charset=utf-8")
		.body("TravellerinformationResponse.page", equalTo(1));
		
	}
	//@Test(priority=2)
void testXMLresponse1(){  //Approach 1
		
		Response res = given()
		.when()
		.get("https://restapi.adeuuateshop.com/api/Traveler?page=1");
		Assert.assertEquals(res.statusCode(), 200);
		Assert.assertEquals(res.header("Content-Type"),"application/xml, charset=utf-8");
		String pageno = res.xmlPath().get("TravellerinformationResponse.page").toString();
		Assert.assertEquals(pageno, "1");
	
	}
	@Test(priority=3)
	void testXMLResponseBody() {
		Response res = given()
				.when()
				.get("https://restapi.adeuuateshop.com/api/Traveler?page=1");
				XmlPath xmlobj = new XmlPath(res.asString());
				//Verify total no of travellers
				List<Object> trevellers = xmlobj.getList("TravellerinformationResponse.travellers.Travelersinformation");
				Assert.assertEquals(trevellers.size(),10);
				
				
				//Verify traveller name is present in response
				List<String> trevellers_names = xmlobj.getList("TravellerinformationResponse.travellers.Travelersinformation.name");
				boolean status=false;
				for(String trevellername:trevellers_names) {
					if(trevellername.equals("Vihaya Kumar")) {
						status=true;
						break;
						
					}
				}
					
				}
}
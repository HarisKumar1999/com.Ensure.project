import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class PostMethod2 {
	@Test
	void post2() {
		RestAssured.useRelaxedHTTPSValidation(); 
		String Jsonbody = " {\r\n"
				+ "    \"firstname\" : \"Jim\",\r\n"
				+ "    \"lastname\" : \"Brown\",\r\n"
				+ "    \"totalprice\" : 111,\r\n"
				+ "    \"depositpaid\" : true,\r\n"
				+ "    \"bookingdates\" : {\r\n"
				+ "        \"checkin\" : \"2018-01-01\",\r\n"
				+ "        \"checkout\" : \"2019-01-01\"\r\n"
				+ "    },\r\n"
				+ "    \"additionalneeds\" : \"Breakfast\"\r\n"
				+ "}";
	Response	res = given()
			.contentType(ContentType.JSON)
			.body(Jsonbody)
		.when()
		.post("https://restful-booker.herokuapp.com/booking");
	res.then()

	  .log().all()
	        // NOTE: Some setups return 200, others return 201 for create booking.
	        // If you see 201 in your console, change to .statusCode(201)
	        .statusCode(anyOf(is(200), is(201)))
	        .header("Content-Type", containsString("application/json"))
	        .body("bookingid", notNullValue())
	        .body("booking.firstname", equalTo("Jim"))
	        .body("booking.totalprice", equalTo(111));


	//System.out.println(res.statusCode());
	//System.out.println(res.getBody().asPrettyString());
	//System.out.println(res.header(Jsonbody));
	//System.out.println(res.getHeaders().toString());
	//System.out.println(res.getHeader("Content-Type"));
	
	// Get specific values
	/*int bookingid = res.jsonPath().getInt("bookingid");
	String fname = 	res.jsonPath().getString("booking.firstname");
	int totalprice = res.jsonPath().getInt("booking.totalprice");
	String checkin = res.jsonPath().getString("booking.bookingdates.checkin");
	
	System.out.println(bookingid);
	System.out.println(fname);
	System.out.println(totalprice);
	System.out.println(checkin);
	
	}*/

		
	}
}

